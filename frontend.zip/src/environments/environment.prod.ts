export const environment = {
  production: true,
  apiUrl: 'https://api.connected.com' // Cambiar por tu URL de producción
};
